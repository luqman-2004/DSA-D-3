
#include <iostream>
#include <stack>
using namespace std;

int main() {
    char text[500] = "", temp[500];
    stack<char*> undo, redo;
    int ch, i, j;

    do {
        cout << "\n1. type\n2. delete\n3. undo\n4. redo\n5. show\n6. exit\n";
        cin >> ch;
        cin.ignore(1000, '\n');

        if (ch == 1) {
            cout << "enter text: ";
            cin.getline(temp, 500);

            char* p = new char[500];
            for (i = 0; text[i]; i++) p[i] = text[i];
            p[i] = '\0';
            undo.push(p);

            for (i = 0; text[i]; i++);
            for (j = 0; temp[j] && i < 499; j++)
                text[i++] = temp[j];
            text[i] = '\0';

            while (!redo.empty()) {
                delete[] redo.top();
                redo.pop();
            }
        }
        else if (ch == 2) {
            for (i = 0; text[i]; i++);
            if (i > 0) {
                char* p = new char[500];
                for (j = 0; text[j]; j++) p[j] = text[j];
                p[j] = '\0';
                undo.push(p);
                text[i - 1] = '\0';
            }
        }
        else if (ch == 3 && !undo.empty()) {
            char* p = new char[500];
            for (i = 0; text[i]; i++) p[i] = text[i];
            p[i] = '\0';
            redo.push(p);

            for (i = 0; undo.top()[i]; i++)
                text[i] = undo.top()[i];
            text[i] = '\0';
            delete[] undo.top();
            undo.pop();
        }
        else if (ch == 4 && !redo.empty()) {
            char* p = new char[500];
            for (i = 0; text[i]; i++) p[i] = text[i];
            p[i] = '\0';
            undo.push(p);

            for (i = 0; redo.top()[i]; i++)
                text[i] = redo.top()[i];
            text[i] = '\0';
            delete[] redo.top();
            redo.pop();
        }
        else if (ch == 5)
            cout << text << endl;

    } while (ch != 6);

    while (!undo.empty()) {
        delete[] undo.top();
        undo.pop();
    }
    while (!redo.empty()) {
        delete[] redo.top();
        redo.pop();
    }

    return 0;
}
