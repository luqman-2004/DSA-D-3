#include <iostream>
using namespace std;

template <typename t>
class abstractstack {
public:
    virtual void push(t) = 0;
    virtual t pop() = 0;
    virtual t top() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;
    virtual ~abstractstack() {}
};

template <typename t>
class myStack : public abstractstack<t> {
    t* arr, * minarr;
    int size, tos;

public:
    myStack(int s) {
        size = s;
        arr = new t[size];
        minarr = new t[size];
        tos = -1;
    }

    void push(t x) override {
        if (isFull()) {
            cout << "stack is full" << endl;
            return;
        }

        tos++;
        arr[tos] = x;
        minarr[tos] = (tos == 0 || x < minarr[tos - 1])
            ? x : minarr[tos - 1];
    }

    t pop() override {
        if (isEmpty()) {
            cout << "stack is empty" << endl;
            return t{};
        }
        return arr[tos--];
    }

    t top() const override {
        return isEmpty() ? t{} : arr[tos];
    }

    t getMin() const {
        return isEmpty() ? t{} : minarr[tos];
    }

    bool isEmpty() const override {
        return tos == -1;
    }

    bool isFull() const override {
        return tos == size - 1;
    }

    void display() const {
        for (int i = tos; i >= 0; i--)
            cout << arr[i] << endl;
    }

    ~myStack() override {
        delete[] arr;
        delete[] minarr;
    }
};

int main() {
    int n, ch, x;
    cout << "enter stack size: ";
    cin >> n;

    if (n <= 0) return 0;

    myStack<int> s(n);

    do {
        cout << "\n1.push\n2.pop\n3.top\n4.isempty\n";
        cout << "5.isfull\n6.display\n7.show minimum\n8.exit\n";
        cout << "enter choice: ";
        cin >> ch;

        switch (ch) {
        case 1:
            cout << "enter value: ";
            cin >> x;
            s.push(x);
            break;

        case 2:
            if (!s.isEmpty())
                cout << s.pop() << endl;
            else
                cout << "stack is empty" << endl;
            break;

        case 3:
            if (!s.isEmpty())
                cout << s.top() << endl;
            else
                cout << "stack is empty" << endl;
            break;

        case 4:
            cout << (s.isEmpty() ? "yes" : "no") << endl;
            break;

        case 5:
            cout << (s.isFull() ? "yes" : "no") << endl;
            break;

        case 6:
            s.display();
            break;

        case 7:
            if (!s.isEmpty())
                cout << "minimum: " << s.getMin() << endl;
            else
                cout << "stack is empty" << endl;
            break;
        }
    } while (ch != 8);

    return 0;
}