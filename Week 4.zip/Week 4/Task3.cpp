#include <iostream>
using namespace std;

class myCarStack {
    string cars[8];
    int top;

public:
    myCarStack() {
        top = -1;
    }

    bool isEmpty() {
        return top == -1;
    }

    bool isFull() {
        return top == 7;
    }

    void push(string car) {
        if (isFull())
            cout << "parking full" << endl;
        else
            cars[++top] = car;
    }

    string pop() {
        if (isEmpty()) return "";
        return cars[top--];
    }

    string peek() {
        if (isEmpty()) return "";
        return cars[top];
    }

    void display() {
        for (int i = top; i >= 0; i--)
            cout << cars[i] << endl;
    }

    void search(string car) {
        for (int i = 0; i <= top; i++) {
            if (cars[i] == car) {
                cout << "car found" << endl;
                return;
            }
        }
        cout << "car not found" << endl;
    }

    void removeCar(string car) {
        myCarStack temp;
        bool found = false;

        while (!isEmpty()) {
            string x = pop();
            if (x == car) {
                found = true;
                break;
            }
            temp.push(x);
        }

        while (!temp.isEmpty())
            push(temp.pop());

        cout << (found ? "car removed" : "car not found") << endl;
    }
};

int main() {
    myCarStack p;
    string car;
    int ch;

    do {
        cout << "\n1. park car\n2. remove car\n3. display cars\n";
        cout << "4. total cars\n5. search car\n6. top car\n7. exit\n";
        cin >> ch;

        switch (ch) {
        case 1:
            cout << "car number: ";
            cin >> car;
            p.push(car);
            break;

        case 2:
            cout << "car number: ";
            cin >> car;
            p.removeCar(car);
            break;

        case 3:
            p.display();
            break;

        case 4: {
            int count = 0;
            myCarStack temp;
            while (!p.isEmpty()) {
                temp.push(p.pop());
                count++;
            }
            while (!temp.isEmpty())
                p.push(temp.pop());
            cout << "total cars: " << count << endl;
            break;
        }

        case 5:
            cout << "car number: ";
            cin >> car;
            p.search(car);
            break;

        case 6:
            if (!p.isEmpty())
                cout << p.peek() << endl;
            else
                cout << "parking empty" << endl;
            break;
        }
    } while (ch != 7);

    return 0;
}